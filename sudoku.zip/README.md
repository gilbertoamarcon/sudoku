# sudoku
Command line arguments:
	-v: verbose mode, prints out the initial and the final values and domain for the entire board.
	-o: ordering, set variable order for assignment as most constrained variable, instead of fixed order.
	-r: rules, apply propagation rules.